<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>
<?php $form = ActiveForm::begin() ?>

<h1>Форма заявки</h1>
<?= array_shift($info) ?>
<?= $form->field($task_form_model, 'title')->textInput(['autofocus' => true]) ?>

<?= $form->field($task_form_model, 'type_id')->dropDownList([
	1=>'Сервисное обслуживание',
	2=>'Поддержка',
	3=>'Запрос технической информации'],['Selected'=>true])?>

<?= $form->field($task_form_model, 'priority_id')->dropDownList([
	1=>'Низкий',
	2=>'Седний',
	3=>'Высокий'])?>

<?= $form->field($task_form_model, 'body')->textarea(['rows' => 6])?>

<h1>Контактная информация</h1>
<?= $form->field($user_form_model, 'surname') ?>

<?= $form->field($user_form_model, 'name') ?>

<?= $form->field($user_form_model, 'patronymic') ?>

<?= $form->field($user_form_model, 'email') ?>

<?= $form->field($user_form_model, 'phone')->widget(\yii\widgets\MaskedInput::className(), [
  'mask' => '+7 (999) 999 99 99']) ?>

 <?= $form->field($user_form_model, 'verifyCode')->widget(\yii\captcha\Captcha::className(), ['template' => '<div class="row"><div class="col-lg-3">{image}</div><div class="col-lg-6">{input}</div></div>',]) ?>

<?= Html::submitButton('Отправить', ['class'=>'btn btn-success']) ?>

<?php ActiveForm::end() ?>