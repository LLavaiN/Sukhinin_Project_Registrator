<?php
namespace app\models;

use yii\db\ActiveRecord;

class TaskForm extends ActiveRecord
{


	public function attributeLabels()
	{
		return [
			'id'=>'Заявка №',
            'title' => 'Название заявки',
            'type_id' => 'Тип заявки',
            'priority_id' => 'Приоритет заявки',
            'body' => 'Описание заявки',
            'user_id' => 'ID пользователя',
            'created_at' => 'Дата создания',
            'updated_at' => 'Дата изменеия',
            'status_id' => 'Статус заявки',
            'comment' => 'Коментарий'
        ];
	}

	public function rules()
	{
		return [
			[['title','body','priority_id','type_id','user_id','status_id','comment'],'required','message'=>'Поле не должно быть пустым']
		];
	}

	public static function tableName()
	{
		return '{{%task_form}}';
	}

	public function getType()
	{
		return $this->hasOne(Type::className(),['t_id' => 'type_id']);
	}

	public function getPriority()
	{
		return $this->hasOne(Priority::className(),['p_id'=>'priority_id']);
	}

	public function getUser()
	{
		return $this->hasOne(UserForm::className(),['u_id'=>'user_id']);
	}

	public function getStatus()
	{
		return $this->hasOne(Status::className(),['s_id'=>'status_id']);
	}



}