<?php
namespace app\models;

use yii\db\ActiveRecord;

class Priority extends ActiveRecord
{


	public function attributeLabels()
	{
		return [
            'value' => 'Приоритет заявки'
        ];
	}

	public function rules()
	{
		return [
			[['value'],'required']
		];
	}

	public static function tableName()
	{
		return '{{%priority}}';
	}

}