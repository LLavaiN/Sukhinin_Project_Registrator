<?php
namespace app\models;

use yii\db\ActiveRecord;

class UserForm extends ActiveRecord
{

	public $verifyCode;

	public function attributeLabels()
	{
		return [

            'name' => 'Имя',
            'surname' => 'Фамилия',
            'patronymic' => 'Отчество',
            'email' => 'Почта',
            'phone' => 'Номер телефона',
            'verifyCode' => 'Код с картинки'
        ];
	}

	public function rules()
	{
		return [
			[['surname','name','patronymic','email','phone','verifyCode'],'required','message'=>'Поле не должно быть пустым'],
			[['email'],'email', 'message'=>'Неверный email'],
			// [['verifyCode'],'captcha','message'=>'Неверный код']
			['verifyCode', 'captcha','captchaAction'=>'site/captcha']
		];
	}

	public static function tableName()
	{
		return '{{%user_form}}';
	}

}
