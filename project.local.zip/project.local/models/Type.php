<?php
namespace app\models;

use yii\db\ActiveRecord;

class Type extends ActiveRecord
{


	public function attributeLabels()
	{
		return [
            'value' => 'Тип заявки'
        ];
	}

	public function rules()
	{
		return [
			[['value'],'required']
		];
	}

	public static function tableName()
	{
		return '{{%type}}';
	}

}