<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\TaskForm;
use app\models\Type;
use app\models\Priority;
use app\models\UserForm;
use app\models\Status;

class TaskFormSearch extends TaskForm
{
    
    public $typeName;
    public $priorityName;
    public $userName;
    public $statusName;

    public function rules()
    {
        return [
            [['id', 'type_id', 'priority_id', 'user_id'], 'integer'],
            [['title', 'body', 'created_at', 'updated_at',
            'typeName','priorityName','userName','statusName'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = TaskForm::find();
        $query->joinWith(['type']);
        $query->joinWith(['priority']);
        $query->joinWith(['user']);
        $query->joinWith(['status']);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $dataProvider->sort->attributes['typeName'] = [
            'asc' => [Type::tableName().'.value' => SORT_ASC],
            'desc' => [Type::tableName().'.value' => SORT_DESC],
        ];
         $dataProvider->sort->attributes['priorityName'] = [
            'asc' => [Priority::tableName().'.value' => SORT_ASC],
            'desc' => [Priority::tableName().'.value' => SORT_DESC],
        ];
        $dataProvider->sort->attributes['userName'] = [
            'asc' => [UserForm::tableName().'.email' => SORT_ASC],
            'desc' => [UserForm::tableName().'.email' => SORT_DESC],
        ];
        $dataProvider->sort->attributes['statusName'] = [
            'asc' => [Status::tableName().'.value' => SORT_ASC],
            'desc' => [Status::tableName().'.value' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'type_id' => $this->type_id,
            'priority_id' => $this->priority_id,
            'user_id' => $this->user_id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);

        $query->andFilterWhere(['like', 'title', $this->title])
            ->andFilterWhere(['like', 'body', $this->body])
            ->andFilterWhere(['like', Type::tableName().'.value', $this->typeName])
            ->andFilterWhere(['like', Priority::tableName().'.value', $this->priorityName])
            ->andFilterWhere(['like', UserForm::tableName().'.email', $this->userName])
            ->andFilterWhere(['like', Status::tableName().'.value', $this->statusName]);

        return $dataProvider;
    }
}
