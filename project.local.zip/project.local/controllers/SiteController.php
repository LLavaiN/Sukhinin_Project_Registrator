<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\UserForm;
use app\models\TaskForm;

class SiteController extends Controller
{

	public function actions()
    {
        return [
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ]
        ];
    }

	public function actionIndex(){

		$user_form_model = new UserForm();
		$task_form_model = new TaskForm();
		$info = array();
		
		if($user_form_model->load(Yii::$app->request->post()) && $task_form_model->load(Yii::$app->request->post()))
		{
			
			$user_finder = UserForm::find()->where([
				'email' => $user_form_model->email,
			])->one();

			$task_finder = TaskForm::find()->where([
				'title' => $task_form_model->title,
			])->one();
			
			if(! isset($task_finder))
			{

				if(isset($user_finder))
				{
					$task_form_model->user_id = $user_finder->u_id;
				}
				else
				{
					$user_form_model->save(false);
					$task_form_model->user_id = $user_form_model->u_id;
				}
				$task_form_model->created_at = date('Y-m-d H:i:s');
				$task_form_model->updated_at = date('Y-m-d H:i:s');
				$task_form_model->save(false);
				$info[] = 'Заявка успешно зарегистрирована';
				return $this->refresh();
			}
			else
			{
				$info[] = 'Заявка с таким названием уже существует';
			}
			

			
        }

		return $this->render('index',compact('user_form_model','task_form_model','info'));
	}
}

