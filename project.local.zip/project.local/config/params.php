<?php

return [
	'adminLogin' => 'root',
	'adminPassword' => '123456',
    'adminEmail' => 'admin@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
];
