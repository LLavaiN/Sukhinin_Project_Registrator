<?php
namespace app\modules\admin\models;

use Yii;
use yii\base\Model;

class LoginForm extends Model {

    public $login;
    public $password;

    public function rules() {
        return [

            [['login', 'password'], 'trim'],
            [
                ['login', 'password'],
                'required',
                'message' => 'Это поле обязательно для заполнения'
            ],
            [['password'], 'string', 'min' => 6],
        ];
    }

    public function attributeLabels() {
        return [
            'login' => 'Логин',
            'password' => 'Пароль',
        ];
    }

    public static function login() {
        session_start();
        $_SESSION['admin'] = 'logined';
    }

    public static function logout() {
        unset($_SESSION['admin']);
        
    }
}