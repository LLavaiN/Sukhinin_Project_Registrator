<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

$this->title = $model->title;

\yii\web\YiiAsset::register($this);
?>
<div class="task-form-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= DetailView::widget([
        'formatter' => ['class' => 'yii\i18n\Formatter','nullDisplay' => ''],
        'model' => $model,
        'attributes' => [
            'id',
            'title',
            'type.value',
            'priority.value',
            'body:ntext',
            'user.surname',
            'user.name',
            'user.patronymic',
            'user.email',
            'user.phone',
            'created_at',
            'updated_at',
            'status.value',
            'comment'
        ]
    ]) ?>

    <p>
        <?= Html::a('Изменить', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Вы уверены, что хотите удалить этот элемент?',
                'method' => 'post',
            ],
        ]) ?>
        <?= Html::a('На главную', ['index', 'id' => $model->id], ['class' => 'btn btn-success']) ?>
    </p>


</div>
