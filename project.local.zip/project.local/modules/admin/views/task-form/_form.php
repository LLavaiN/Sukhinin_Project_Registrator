<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

?>

<div class="task-form-form">

    <?php $form = ActiveForm::begin(); ?>



    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'type_id')->dropDownList([
    1=>'Сервисное обслуживание',
    2=>'Поддержка',
    3=>'Запрос технической информации'],['Selected'=>true])?>

    <?= $form->field($model, 'priority_id')->dropDownList([
    1=>'Низкий',
    2=>'Седний',
    3=>'Высокий'])?>

    <?= $form->field($model, 'body')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'status_id')->dropDownList([
    1=>'Новая',
    2=>'В работе',
    3=>'Выполнена',
    4=>'Отложена',
    5=>'Решена'])?>

    <?= $form->field($model, 'comment')->textarea(['rows' => 6]) ?>

    <div class="form-group">

        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']); ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
