<?php
namespace app\modules\admin\controllers;

use Yii;
use yii\web\Controller;

class AdminController extends Controller {

    public function beforeAction($action) {
        if (!isset($_SESSION['admin'])) {
            $this->redirect('/web/admin/auth/login');
            return false;
        }

        return parent::beforeAction($action);
    }
}