<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%priority}}`.
 */
class m191110_153345_create_priority_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%priority}}', [
            'p_id' => $this->primaryKey(),
            'value' => $this->string()
        ]);

        $this->batchInsert('{{%priority}}', ['value'], [
          ['Низкий'],
          [ 'Средний'],
          ['Высокий']
        ]);
    }

    
    public function safeDown()
    {
        $this->dropTable('{{%priority}}');
    }
}
