<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%type}}`.
 */
class m191110_153354_create_type_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%type}}', [
            't_id' => $this->primaryKey(),
            'value' => $this->string()
        ]);

        $this->batchInsert('{{%type}}', ['value'], [
          ['Сервисное обслуживание'],
          [ 'Поддержка'],
          ['Запрос технической информации']
        ]);

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%type}}');
    }
}
