<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%status}}`.
 */
class m191112_200601_create_status_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%status}}', [
            's_id' => $this->primaryKey(),
            'value' => $this->string()
        ]);

        $this->batchInsert('{{%status}}', ['value'], [
          ['Новая'],
          [ 'В работе'],
          ['Выполнена'],
          ['Отложена'],
          ['Решена']
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%status}}');
    }
}
