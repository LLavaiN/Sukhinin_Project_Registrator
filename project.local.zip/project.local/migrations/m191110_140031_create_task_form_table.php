<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%task_form}}`.
 */
class m191110_140031_create_task_form_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%task_form}}', [
            
            'id' => $this->primaryKey(),
            'title' => $this->string(),
            'type_id' => $this->integer(),
            'priority_id' => $this->integer(),
            'body' => $this->text(),
            'user_id' => $this->integer(),
            'created_at' => $this->datetime()->notNull(),
            'updated_at' => $this->datetime()->notNull(),
            'status_id' => $this->integer()->defaultValue('1'),
            'comment' => $this->text()
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%task_form}}');
    }
}
