<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%user_form}}`.
 */
class m191109_222131_create_user_form_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%user_form}}', [
            'u_id' => $this->primaryKey(),
            'surname' => $this->string(),
            'name' => $this->string(),
            'patronymic' => $this->string(),
            // 'login' => $this->string(),
            'email' =>$this->string(),
            'phone' => $this->string(),
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%user_form}}');
    }
}
